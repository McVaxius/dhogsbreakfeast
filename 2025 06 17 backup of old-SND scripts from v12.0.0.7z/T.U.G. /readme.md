## Did you come here for a TUG ing?

##Technically Useful Goodies (T.U.G.)

Script folder of random garbage or script snippet examples mostly pulled from the old repo but maybe new stuff will appear from community etc.