##Welcome to Sneaky Uncle Steven's Scripts (S.U.S.S.)

uncle steven will ocasionally provide a script and it will go here. don't ask dhog or me for support (we aren't uncle steven.) and don't ask in any discords. 