--turn on bmr follow target mode, and rsr and enjoy
fuckyou = 1

while fuckyou == 1 and GetCharacterCondition(34) == true do

yield("/target Bakool")
yield("/target Thug")
yield("/send KEY_1")
yield("/send KEY_3")
yield("/send KEY_5")
yield("/wait 0.5")
end