##
_functions.lua
its here in the root so you can find it easily.
please enjoy.

## This is stolen from the SND repo before the community scripts part goes offline forever. here it is. please enjoy
idk what i will do with it. i suppose i will move all the non-mine-scripts into some folder and call them archival reference scripts or delete them.

## Community Scripts

Here are many of the community made scripts to automate many aspects of the game. A lot of them utilise or are companions to other automation tools such as AutoRetainer, visland, Pandora's Box, Automaton, Artisan, or YesAlready. Requirements are generally listed in the description if any are needed.

Many of these were originally posted to [Liza's Discord](https://discord.com/invite/eqw3TpQKyb) or the [Puni.sh Discord](https://discord.gg/Zzrcc8kmvy), and links to the original posts are included in the header comments of each file.

### Other Scripts

[plottingCreeper's Repo](https://github.com/plottingCreeper/FFXIV-scripts-and-macros/)

[LTS's Repo](https://github.com/LTS-FFXIV/SNDScripts/)
