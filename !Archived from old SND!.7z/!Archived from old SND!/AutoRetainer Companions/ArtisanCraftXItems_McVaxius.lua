--[[
  Description: Craft x amount of items before resuming multi
  Author: McVaxius
  Link: https://discord.com/channels/1162031769403543643/1162799234874093661/1164982898026364998
]]
